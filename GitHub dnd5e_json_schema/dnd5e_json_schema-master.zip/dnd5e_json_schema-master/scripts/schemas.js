const schemas = [
    "Character",
    "Class",
    "Creature",
    "Monster",
    "Race",
    "Spell",
    "action",
    "damage_type",
    "dice",
    "conditions",
    "equipment",
    "feat",
    "feature",
    "image",
    "item",
    "senses",
    "source",
    "tag",
    "weapon"
];

module.exports = { schemas };