# dnd5e_json_schema
Standardized JSON Schemas for Dungeons &amp; Dragons 5th Edition.

## Helpful Links
[JSON Schema](https://json-schema.org/)

[JSON Schema Validator](https://www.jsonschemavalidator.net/)
