&#36;schema: [http://json-schema.org/draft-07/schema#](http://json-schema.org/draft-07/schema#)

<b id="tag.schema.json">&#36;id: tag.schema.json</b>

_This schema describes a generic tag._

&#36;comment: _version 0.1.1_

Type: `array`

 - **_Items_**
 - <i id="/items">path: /items</i>
 - Type: `string`
 - Examples: 
	 1. _"Wizard"_
	 2. _"Bronze Dragon"_
	 3. _"Orc"_

_Generated with [json-schema-md-doc](https://brianwendt.github.io/json-schema-md-doc/)_