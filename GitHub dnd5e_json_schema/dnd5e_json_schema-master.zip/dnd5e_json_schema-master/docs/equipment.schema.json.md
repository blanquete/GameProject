# JSON Schema for D&D 5e equiment.

&#36;schema: [http://json-schema.org/draft-07/schema#](http://json-schema.org/draft-07/schema#)

<b id="equipment.schema.json">&#36;id: equipment.schema.json</b>

_This schema describes an equipment item. The schema extends item.schema.json_

&#36;comment: _version 0.1.1_

Type: `object`

**_Properties_**

 - <i id="/properties/quantity">quantity</i>
	 - <i id="/properties/quantity">path: /properties/quantity</i>
	 - Type: `integer`
	 - Default: `0`

_Generated with [json-schema-md-doc](https://brianwendt.github.io/json-schema-md-doc/)_