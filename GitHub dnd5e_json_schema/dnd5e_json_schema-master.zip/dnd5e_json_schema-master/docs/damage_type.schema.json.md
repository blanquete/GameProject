# JSON Schema for D&D 5e Damage Type.

&#36;schema: [http://json-schema.org/draft-07/schema#](http://json-schema.org/draft-07/schema#)

<b id="damage_type.schema.json">&#36;id: damage_type.schema.json</b>

_This schema describes a string value of a Damage Type._

&#36;comment: _version 0.1.1_

Type: `string`

Examples: 

 1. _"none"_
 2. _"Piercing"_
 3. _"Slashing"_
 4. _"Bludgeoning"_
 5. _"Acid"_
 6. _"Cold"_
 7. _"Fire"_
 8. _"Force"_
 9. _"Lightning"_
 10. _"Necrotic"_
 11. _"Poison"_
 12. _"Psychic"_
 13. _"Radiant"_
 14. _"Thunder"_
Default: _"none"_


_Generated with [json-schema-md-doc](https://brianwendt.github.io/json-schema-md-doc/)_