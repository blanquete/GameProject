# Traducción al español de D&D5e [![Crowdin](https://badges.crowdin.net/dnd5e-es-compendium/localized.svg)](https://crowdin.com/project/dnd5e-es-compendium)


# DESACTUALIZADO
Recomiendo encarecidamente utilizar la nueva traducción de los compendios que se está desarrollando.

Puedes encontrar el repositorio [aquí](https://github.com/HonzoNebro/dnd5e-es-compendium) o dentro de la sección de módulos de Foundry, como **Translation: Spanish Babele [DnD5e and Compendiums]**.

# Traducción al español de D&D5e

## Descripción

Fork para la nueva traducción al Español del Sistema y los Compendios (incompleta) de D&D5e para **Foundry VTT**. 

Los nuevos compendios están siendo traducidos por la comunidad española de Foundry VTT, en [Discord](https://discord.gg/papqPzS) y [Telegram](https://t.me/FoundryVTT_ES)

Si quieres colaborar, estamos [en nuestro discord para la traducción](https://discord.gg/yyHCETcnVt) donde podremos coordinarnos.

## Instalación

Para la traducción de los compendios necesitas tener instalado el modulo Babele, que se puede hacer desde la sección de Modulos de Foundry.

Puedes instalar este módulo introduciendo [esta dirección](https://raw.githubusercontent.com/HonzoNebro/dnd5e-es-compendium/master/module.json) en **Instalar Módulo**.

Dentro del mundo deberás tener activado Babele (no hace falta configurarlo) y este módulo.
